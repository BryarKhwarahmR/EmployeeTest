
public class EmployeeTest{
        public static void main(String[] args){
 

        // Create two Employee objects.
        Employee employee1 = new Employee("Yusra", "Mohammad", 20000.00);
        Employee employee2 = new Employee("Peshang", "Mohammad", 55000.00);

        // Display each object's yearly salary.
        System.out.println("NAME\tYEARLY SALARY");
        System.out.println(employee1.getFirstName() + " " + employee1.getLastName() + "\t" + employee1.getYearlySalary());
        System.out.println(employee2.getFirstName() + " " + employee2.getLastName() + "\t" + employee2.getYearlySalary());

        // Give each Employee a 10% raise and display each Employee's yearly salary again.
        System.out.println("10 Percent Salary Raised!! Yoohooooo!");
        employee1.setMonthlySalary(employee1.getMonthlySalary() * 1.10);
        employee2.setMonthlySalary(employee2.getMonthlySalary() * 1.10);

        // Display each object's yearly salary.
        System.out.println("NAME\tYEARLY SALARY");
        System.out.println(employee1.getFirstName() + " " + employee1.getLastName() + "\t" + employee1.getYearlySalary());
        System.out.println(employee2.getFirstName() + " " + employee2.getLastName() + "\t" + employee2.getYearlySalary());

        // Create a Manager object.
        Manager manager = new Manager("John", "Doe", 100000.00, "Engineering");

        // Display the Manager's department.
        System.out.println("Manager's department: " + manager.getDepartment());
    }
}