
class Employee {
    private String firstName;
    private String lastName;
    private final double MONTHLY_SALARY_MIN = 0.0;
    private double monthlySalary;

    public Employee(String firstName, String lastName, double monthlySalary) {
        if (monthlySalary < MONTHLY_SALARY_MIN) {
            throw new IllegalArgumentException("Monthly salary cannot be negative.");
        }
        this.firstName = firstName;
        this.lastName = lastName;
        this.monthlySalary = monthlySalary;
    }

    public String getFirstName()
 
{
        return firstName;
    }

    public void setFirstName(String firstName)
 
{
        this.firstName = firstName;
    }

    public String getLastName()
 
{
        return lastName;
    }

    public void setLastName(String lastName)
 
{
        this.lastName = lastName;
    }

    public double getMonthlySalary()
 
{
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary)
 
{
        if (monthlySalary < MONTHLY_SALARY_MIN) {
            throw new IllegalArgumentException("Monthly salary cannot be negative.");
        }
        this.monthlySalary = monthlySalary;
    }

    public double getYearlySalary() {
        return monthlySalary * 12.0;
    }
}

// Inheritance
class Manager extends Employee {
    private String department;

    public Manager(String firstName, String lastName, double monthlySalary, String department) {
        super(firstName, lastName, monthlySalary);
        this.department = department;
    }

    public String getDepartment()
 
{
        return department;
    }

    public void setDepartment(String department)
 
{
        this.department = department;
    }
}


